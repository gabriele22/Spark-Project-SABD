#!/bin/bash
docker-compose exec --user=root spark-master spark/bin/spark-submit --class "Query3" --master spark://spark-master:7077 /opt/spark-apps/Spark-Project.jar  "hdfs://namenode:8020/city_attributes.csv" "hdfs://namenode:8020/temperature.csv" redis
