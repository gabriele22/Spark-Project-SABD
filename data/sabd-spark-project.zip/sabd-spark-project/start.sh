#!/bin/bash
sh ./build-images.sh
docker-compose up -d 

sleep 30 #wait until containers are up and running

#insert pairs city-nation on redis
docker cp ./support/worldCities.csv redis:/tmp
docker-compose exec --user=root redis awk -F, '{print " SET \""$1"\" \""$2"\" \n"}' /tmp/worldCities.csv | redis-cli --pipe 

#dataset files from host to namenode container
docker cp ./prj1_dataset/weather_description.csv namenode:/weather_description.csv
docker cp ./prj1_dataset/city_attributes.csv namenode:/city_attributes.csv
docker cp ./prj1_dataset/temperature.csv namenode:/temperature.csv

#files from container to HDFS
docker-compose exec --user=root namenode hdfs dfs -put city_attributes.csv /city_attributes.csv
docker-compose exec --user=root namenode hdfs dfs -put weather_description.csv /weather_description.csv
docker-compose exec --user=root namenode hdfs dfs -put temperature.csv /temperature.csv

#copy app jar to shared volume
sudo cp ./Spark-Project.jar /mnt/spark-apps
sudo cp ./support/timeZone.csv /mnt/spark-data




