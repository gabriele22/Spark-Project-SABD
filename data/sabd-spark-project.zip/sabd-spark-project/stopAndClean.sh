#!/bin/bash
docker-compose stop
docker-compose rm
sudo rm -r ./data
